# Elementary MVVM App

Flutter-приложение, выполненное с использованием Clean Architecture и MVVM на Elementary.

## Что реализовано

- разделение на слои: domain, data, presentation;
- MVVM через ElementaryWidget, WidgetModel и ElementaryModel;
- список задач на главном экране;
- добавление задач;
- изменение статуса задачи;
- удаление задач;
- чистая структура проекта.

## Технологии

- Flutter
- Dart
- elementary
- Clean Architecture
- MVVM

## Запуск

```bash
flutter pub get
flutter run
```

## Структура

```text
lib/
  main.dart
  features/
    todos/
      domain/
        entities/
        repositories/
        usecases/
      data/
        repositories/
      presentation/
        todo_list/
```

## Ссылка для сдачи

После загрузки проекта на GitHub нужно отправить ссылку на репозиторий:

```text
https://github.com/USERNAME/elementary_mvvm_app
```
