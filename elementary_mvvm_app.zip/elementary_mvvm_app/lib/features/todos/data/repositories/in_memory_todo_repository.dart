import '../../domain/entities/todo_entity.dart';
import '../../domain/repositories/todo_repository.dart';

class InMemoryTodoRepository implements TodoRepository {
  int _lastId = 3;

  final List<TodoEntity> _todos = const [
    TodoEntity(id: 1, title: 'Изучить Clean Architecture', isDone: true),
    TodoEntity(id: 2, title: 'Подключить Elementary', isDone: false),
    TodoEntity(id: 3, title: 'Залить проект на GitHub', isDone: false),
  ].toList();

  @override
  Future<List<TodoEntity>> getTodos() async {
    await Future<void>.delayed(const Duration(milliseconds: 300));
    return List.unmodifiable(_todos);
  }

  @override
  Future<List<TodoEntity>> addTodo(String title) async {
    if (title.trim().isEmpty) return getTodos();

    _todos.add(
      TodoEntity(
        id: ++_lastId,
        title: title.trim(),
        isDone: false,
      ),
    );

    return getTodos();
  }

  @override
  Future<List<TodoEntity>> toggleTodo(int id) async {
    final index = _todos.indexWhere((todo) => todo.id == id);

    if (index != -1) {
      final todo = _todos[index];
      _todos[index] = todo.copyWith(isDone: !todo.isDone);
    }

    return getTodos();
  }

  @override
  Future<List<TodoEntity>> deleteTodo(int id) async {
    _todos.removeWhere((todo) => todo.id == id);
    return getTodos();
  }
}
