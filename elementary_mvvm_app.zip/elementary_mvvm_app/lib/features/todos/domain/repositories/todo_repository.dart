import '../entities/todo_entity.dart';

abstract class TodoRepository {
  Future<List<TodoEntity>> getTodos();
  Future<List<TodoEntity>> addTodo(String title);
  Future<List<TodoEntity>> toggleTodo(int id);
  Future<List<TodoEntity>> deleteTodo(int id);
}
