import '../entities/todo_entity.dart';
import '../repositories/todo_repository.dart';

class GetTodosUseCase {
  final TodoRepository repository;

  const GetTodosUseCase(this.repository);

  Future<List<TodoEntity>> call() {
    return repository.getTodos();
  }
}
