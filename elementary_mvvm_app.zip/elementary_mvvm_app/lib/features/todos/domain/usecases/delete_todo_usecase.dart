import '../entities/todo_entity.dart';
import '../repositories/todo_repository.dart';

class DeleteTodoUseCase {
  final TodoRepository repository;

  const DeleteTodoUseCase(this.repository);

  Future<List<TodoEntity>> call(int id) {
    return repository.deleteTodo(id);
  }
}
