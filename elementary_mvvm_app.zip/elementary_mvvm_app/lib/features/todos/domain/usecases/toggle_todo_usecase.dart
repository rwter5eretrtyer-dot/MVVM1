import '../entities/todo_entity.dart';
import '../repositories/todo_repository.dart';

class ToggleTodoUseCase {
  final TodoRepository repository;

  const ToggleTodoUseCase(this.repository);

  Future<List<TodoEntity>> call(int id) {
    return repository.toggleTodo(id);
  }
}
