import '../entities/todo_entity.dart';
import '../repositories/todo_repository.dart';

class AddTodoUseCase {
  final TodoRepository repository;

  const AddTodoUseCase(this.repository);

  Future<List<TodoEntity>> call(String title) {
    return repository.addTodo(title);
  }
}
