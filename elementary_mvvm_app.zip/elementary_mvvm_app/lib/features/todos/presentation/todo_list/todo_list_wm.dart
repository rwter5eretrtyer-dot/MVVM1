import 'package:elementary/elementary.dart';
import 'package:flutter/material.dart';

import '../../data/repositories/in_memory_todo_repository.dart';
import '../../domain/entities/todo_entity.dart';
import '../../domain/usecases/add_todo_usecase.dart';
import '../../domain/usecases/delete_todo_usecase.dart';
import '../../domain/usecases/get_todos_usecase.dart';
import '../../domain/usecases/toggle_todo_usecase.dart';
import 'todo_list_model.dart';
import 'todo_list_screen.dart';

class TodoUiModel {
  final int id;
  final String title;
  final bool isDone;

  const TodoUiModel({
    required this.id,
    required this.title,
    required this.isDone,
  });

  factory TodoUiModel.fromEntity(TodoEntity entity) {
    return TodoUiModel(
      id: entity.id,
      title: entity.title,
      isDone: entity.isDone,
    );
  }
}

abstract interface class ITodoListWidgetModel implements IWidgetModel {
  TextEditingController get controller;
  ValueListenable<List<TodoUiModel>> get todos;
  ValueListenable<bool> get isLoading;

  Future<void> addTodo();
  Future<void> toggleTodo(int id);
  Future<void> deleteTodo(int id);
}

TodoListWidgetModel todoListWidgetModelFactory(BuildContext context) {
  final repository = InMemoryTodoRepository();

  return TodoListWidgetModel(
    TodoListModel(
      getTodosUseCase: GetTodosUseCase(repository),
      addTodoUseCase: AddTodoUseCase(repository),
      toggleTodoUseCase: ToggleTodoUseCase(repository),
      deleteTodoUseCase: DeleteTodoUseCase(repository),
    ),
  );
}

class TodoListWidgetModel extends WidgetModel<TodoListScreen, TodoListModel>
    implements ITodoListWidgetModel {
  final TextEditingController _controller = TextEditingController();
  final ValueNotifier<List<TodoUiModel>> _todos = ValueNotifier([]);
  final ValueNotifier<bool> _isLoading = ValueNotifier(false);

  TodoListWidgetModel(super.model);

  @override
  TextEditingController get controller => _controller;

  @override
  ValueListenable<List<TodoUiModel>> get todos => _todos;

  @override
  ValueListenable<bool> get isLoading => _isLoading;

  @override
  void initWidgetModel() {
    super.initWidgetModel();
    _loadTodos();
  }

  Future<void> _loadTodos() async {
    _isLoading.value = true;
    final result = await model.getTodos();
    _todos.value = result.map(TodoUiModel.fromEntity).toList();
    _isLoading.value = false;
  }

  @override
  Future<void> addTodo() async {
    final title = _controller.text;
    final result = await model.addTodo(title);
    _controller.clear();
    _todos.value = result.map(TodoUiModel.fromEntity).toList();
  }

  @override
  Future<void> toggleTodo(int id) async {
    final result = await model.toggleTodo(id);
    _todos.value = result.map(TodoUiModel.fromEntity).toList();
  }

  @override
  Future<void> deleteTodo(int id) async {
    final result = await model.deleteTodo(id);
    _todos.value = result.map(TodoUiModel.fromEntity).toList();
  }

  @override
  void dispose() {
    _controller.dispose();
    _todos.dispose();
    _isLoading.dispose();
    super.dispose();
  }
}
