import 'package:elementary/elementary.dart';
import 'package:flutter/material.dart';

import 'todo_list_wm.dart';

class TodoListScreen extends ElementaryWidget<ITodoListWidgetModel> {
  const TodoListScreen({
    super.key,
    WidgetModelFactory wmFactory = todoListWidgetModelFactory,
  }) : super(wmFactory);

  @override
  Widget build(ITodoListWidgetModel wm) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('MVVM + Elementary'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: wm.controller,
                    decoration: const InputDecoration(
                      labelText: 'Новая задача',
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                FilledButton(
                  onPressed: wm.addTodo,
                  child: const Text('Добавить'),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Expanded(
              child: ValueListenableBuilder<bool>(
                valueListenable: wm.isLoading,
                builder: (_, isLoading, __) {
                  if (isLoading) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  return ValueListenableBuilder<List<TodoUiModel>>(
                    valueListenable: wm.todos,
                    builder: (_, todos, __) {
                      if (todos.isEmpty) {
                        return const Center(
                          child: Text('Список задач пуст'),
                        );
                      }

                      return ListView.separated(
                        itemCount: todos.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 8),
                        itemBuilder: (_, index) {
                          final todo = todos[index];

                          return Card(
                            child: CheckboxListTile(
                              value: todo.isDone,
                              title: Text(
                                todo.title,
                                style: TextStyle(
                                  decoration: todo.isDone
                                      ? TextDecoration.lineThrough
                                      : TextDecoration.none,
                                ),
                              ),
                              onChanged: (_) => wm.toggleTodo(todo.id),
                              secondary: IconButton(
                                icon: const Icon(Icons.delete_outline),
                                onPressed: () => wm.deleteTodo(todo.id),
                              ),
                            ),
                          );
                        },
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
