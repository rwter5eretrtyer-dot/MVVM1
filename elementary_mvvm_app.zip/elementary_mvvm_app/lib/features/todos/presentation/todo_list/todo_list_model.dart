import 'package:elementary/elementary.dart';

import '../../domain/entities/todo_entity.dart';
import '../../domain/usecases/add_todo_usecase.dart';
import '../../domain/usecases/delete_todo_usecase.dart';
import '../../domain/usecases/get_todos_usecase.dart';
import '../../domain/usecases/toggle_todo_usecase.dart';

class TodoListModel extends ElementaryModel {
  final GetTodosUseCase getTodosUseCase;
  final AddTodoUseCase addTodoUseCase;
  final ToggleTodoUseCase toggleTodoUseCase;
  final DeleteTodoUseCase deleteTodoUseCase;

  TodoListModel({
    required this.getTodosUseCase,
    required this.addTodoUseCase,
    required this.toggleTodoUseCase,
    required this.deleteTodoUseCase,
  });

  Future<List<TodoEntity>> getTodos() {
    return getTodosUseCase();
  }

  Future<List<TodoEntity>> addTodo(String title) {
    return addTodoUseCase(title);
  }

  Future<List<TodoEntity>> toggleTodo(int id) {
    return toggleTodoUseCase(id);
  }

  Future<List<TodoEntity>> deleteTodo(int id) {
    return deleteTodoUseCase(id);
  }
}
